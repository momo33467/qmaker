-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2024 at 09:49 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exams`
--

-- --------------------------------------------------------

--
-- Table structure for table `attempt`
--

CREATE TABLE `attempt` (
  `ID` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `score` double NOT NULL,
  `qid` int(11) NOT NULL,
  `nofqs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attempt`
--

INSERT INTO `attempt` (`ID`, `student`, `score`, `qid`, `nofqs`) VALUES
(10, 3, 3, 14, 7),
(11, 3, 1, 14, 7),
(12, 3, 2, 15, 3),
(13, 3, 1, 20, 1),
(14, 3, 1, 21, 3),
(15, 3, 2, 22, 4),
(16, 3, 5, 14, 9);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `ID` int(11) NOT NULL,
  `text` varchar(65) NOT NULL,
  `qid2` int(11) NOT NULL,
  `iscorrect` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `quiz` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`ID`, `text`, `qid2`, `iscorrect`, `tid`, `quiz`) VALUES
(97, 'a', 25, 0, 2, 14),
(98, 'b2', 25, 0, 2, 14),
(99, 'c', 25, 0, 2, 14),
(100, 'java', 25, 1, 2, 14),
(105, '2x', 27, 0, 2, 15),
(106, 'ss', 27, 0, 2, 15),
(107, 'c', 27, 1, 2, 15),
(108, '4x', 27, 0, 2, 15),
(109, '2x', 28, 1, 2, 15),
(110, 'b', 28, 0, 2, 15),
(111, 'c', 28, 0, 2, 15),
(112, 'd', 28, 0, 2, 15),
(113, '2x', 29, 0, 2, 14),
(114, 'x^2', 29, 1, 2, 14),
(115, '3x', 29, 0, 2, 14),
(116, '4x', 29, 0, 2, 14),
(121, 'a', 31, 0, 2, 14),
(122, 'b', 31, 0, 2, 14),
(123, 'c', 31, 1, 2, 14),
(124, 'd', 31, 0, 2, 14),
(125, 'a', 32, 0, 2, 14),
(126, 'b', 32, 1, 2, 14),
(127, 'c', 32, 0, 2, 14),
(128, 'd', 32, 0, 2, 14),
(129, 'gg', 33, 1, 2, 14),
(130, 'dd', 33, 0, 2, 14),
(131, 'aa', 33, 0, 2, 14),
(132, 's', 33, 0, 2, 14),
(133, 'Hi', 34, 0, 2, 15),
(134, 'Bye', 34, 0, 2, 15),
(135, 'Why', 34, 1, 2, 15),
(136, 'Nai', 34, 0, 2, 15),
(137, '2x', 35, 0, 2, 14),
(138, 'b', 35, 0, 2, 14),
(139, 'c', 35, 1, 2, 14),
(140, 'd', 35, 0, 2, 14),
(145, 'TRUE', 37, 1, 2, 14),
(146, 'FALSE', 37, 0, 2, 14),
(147, '', 37, 0, 2, 14),
(148, '', 37, 0, 2, 14),
(149, 'fine', 38, 0, 4, 20),
(150, 'not fine', 38, 1, 4, 20),
(151, '', 38, 0, 4, 20),
(152, '', 38, 0, 4, 20),
(153, 'Mohammed', 39, 1, 4, 21),
(154, 'Hassan', 39, 0, 4, 21),
(155, 'Ali', 39, 0, 4, 21),
(156, 'Mahfi', 39, 0, 4, 21),
(157, 'No', 40, 0, 4, 21),
(158, 'Yes', 40, 1, 4, 21),
(159, '', 40, 0, 4, 21),
(160, '', 40, 0, 4, 21),
(165, 'TRUE', 42, 0, 4, 20),
(166, 'G', 42, 0, 4, 20),
(167, 'A', 42, 0, 4, 20),
(168, 'S', 42, 1, 4, 20),
(169, '1', 43, 1, 4, 21),
(170, '2', 43, 0, 4, 21),
(171, '3', 43, 0, 4, 21),
(172, '4', 43, 0, 4, 21),
(177, 'T', 45, 1, 2, 22),
(178, '5', 45, 0, 2, 22),
(179, '3', 45, 0, 2, 22),
(180, '', 45, 0, 2, 22),
(181, '1', 46, 0, 2, 22),
(182, '2', 46, 0, 2, 22),
(183, '3', 46, 1, 2, 22),
(184, '4', 46, 0, 2, 22),
(185, 'Q', 47, 0, 2, 22),
(186, 'Ab', 47, 0, 2, 22),
(187, 'E', 47, 0, 2, 22),
(188, 'Q', 47, 1, 2, 22),
(189, 'W', 48, 0, 2, 22),
(190, 'W', 48, 0, 2, 22),
(191, 'W', 48, 1, 2, 22),
(192, 'W', 48, 0, 2, 22),
(193, 'Q2', 49, 0, 2, 14),
(194, 'E', 49, 0, 2, 14),
(195, '4', 49, 0, 2, 14),
(196, '', 49, 1, 2, 14),
(197, 'Yes', 50, 1, 2, 14),
(198, 'No', 50, 0, 2, 14),
(199, '', 50, 0, 2, 14),
(200, '', 50, 0, 2, 14);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `ID` int(11) NOT NULL,
  `text` text NOT NULL,
  `qid` int(11) NOT NULL,
  `tid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`ID`, `text`, `qid`, `tid`) VALUES
(25, 'q01', 14, 2),
(27, 'w', 15, 2),
(28, 'q2', 15, 2),
(29, 'q2', 14, 2),
(31, 'q3', 14, 2),
(32, 'q4', 14, 2),
(33, 'q5', 14, 2),
(34, 'Q2', 15, 2),
(35, 'qs', 14, 2),
(37, 'qidk', 14, 2),
(38, 'how are you?', 20, 4),
(39, 'Name?', 21, 4),
(40, 'Is this good?', 21, 4),
(42, 'What a bug?', 20, 4),
(43, 'Bug', 21, 4),
(45, 'Hi', 22, 2),
(46, '123', 22, 2),
(47, 'R2', 22, 2),
(48, '4', 22, 2),
(49, 'R2', 14, 2),
(50, 'Bug done?', 14, 2);

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `ID` int(11) NOT NULL,
  `name` varchar(65) NOT NULL,
  `tid` int(11) NOT NULL,
  `passcode` varchar(65) NOT NULL,
  `NumOfAttempts` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`ID`, `name`, `tid`, `passcode`, `NumOfAttempts`) VALUES
(14, 'group 2 ', 2, '123', 3),
(15, 'group 3', 2, '1', 1),
(16, 'quiz1_cs311', 2, '123', 1),
(20, 'myexam', 4, '123', 1),
(21, 'new', 4, '123', 5),
(22, 'New2', 2, '123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `name` varchar(65) NOT NULL,
  `age` date NOT NULL,
  `email` varchar(65) NOT NULL,
  `password` varchar(65) NOT NULL,
  `activated` tinyint(1) NOT NULL,
  `code` varchar(65) NOT NULL,
  `role` varchar(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `name`, `age`, `email`, `password`, `activated`, `code`, `role`) VALUES
(2, 'CODERMOMO', '1212-12-12', 'momo3346@outlook.sa', 'de34ddf5af5bcbda0219a7280880a0b7c6ae7b12885160996fe3effaa67733a3', 1, '$2y$10$ShnUHu4GD4A9UxPP6nBzPOLoFgOPtZ9krL4MPg1KNXxiHfHKFIS3O', 'Teacher'),
(3, 'm7mmed', '2003-12-18', 'momo_3346@hotmail.com', 'de34ddf5af5bcbda0219a7280880a0b7c6ae7b12885160996fe3effaa67733a3', 1, '$2y$10$KOSiEUR623jakfks6gBGFekaYGHNGX9TJGSVq23.XR6Kogn7PK7iq', 'Student'),
(4, 'momo', '1212-12-12', 'momo334678@gmail.com', 'de34ddf5af5bcbda0219a7280880a0b7c6ae7b12885160996fe3effaa67733a3', 1, '$2y$10$VlbaAZAeN1SgqvOwm.nDveFuUTe0nfc19jxjqHfQ15aqz3EMxt7MW', 'Teacher');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attempt`
--
ALTER TABLE `attempt`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attempt`
--
ALTER TABLE `attempt`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
